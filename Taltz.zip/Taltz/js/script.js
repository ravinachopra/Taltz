$(document).ready(function(){

	var headerHeight=$('.graphics').height();
	$('.body-content').css('margin-top',-headerHeight);
});